import os
from datetime import datetime, timedelta
from aiocryptopay import AioCryptoPay, Networks
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import ContextTypes

import db

# Ініціалізація CryptoPay
crypto = AioCryptoPay(token=os.getenv("CRYPTOPAY_TOKEN"), network=Networks.MAIN_NET)

async def start_subscription(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Починає процес купівлі підписки."""
    telegram_id = str(update.effective_chat.id)
    user = await db.get_user(telegram_id)

    # Перевірка наявності активної підписки
    if user.subscription_end and user.subscription_end > datetime.utcnow():
        await update.callback_query.edit_message_text("✅ У вас вже є активна підписка!")
        kb = [[InlineKeyboardButton("🔙 Повернутися до меню", callback_data="back")]]
        await update.effective_chat.send_message("Оберіть дію:", reply_markup=InlineKeyboardMarkup(kb))
        return 12  # MAIN_MENU

    # Створення інвойсу на 10$
    amount = 9.99
    invoice = await crypto.create_invoice(
        fiat="USD",
        amount=amount,
        currency_type="fiat",
        accepted_assets=['USDT', 'USDC', 'TON', 'TRX']
    )
    invoice_url = invoice.bot_invoice_url
    invoice_id = invoice.invoice_id

    # Збереження invoice_id в user_data
    context.user_data['invoice_id'] = invoice_id

    await update.callback_query.edit_message_text(
        f"<b>Купівля підписки на тиждень</b>\n"
        f"<b>Сума:</b> <code>{amount}$</code>\n"
        f"<b>ID платежу:</b> <code>{invoice_id}</code>\n"
        f"<b>Щоб оплатити, натисніть кнопку нижче:</b>",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("💳 Оплатити", url=invoice_url),
             InlineKeyboardButton("🔄 Перевірити оплату", callback_data="check_payment")],
            [InlineKeyboardButton("🔙 Скасувати", callback_data="back")]
        ]),
        parse_mode="HTML"
    )
    return 15  # SUBSCRIBE

async def check_payment(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Перевіряє статус оплати та активує підписку, якщо оплата пройшла."""
    invoice_id = context.user_data.get('invoice_id')
    if not invoice_id:
        await update.callback_query.answer("❌ ID інвойсу не знайдено", show_alert=True)
        return 12  # MAIN_MENU

    invoice = await crypto.get_invoices(invoice_ids=invoice_id)
    status = invoice.status

    if status == "paid":
        telegram_id = str(update.effective_chat.id)
        end_date = datetime.utcnow() + timedelta(days=7)
        await db.set_subscription_end(telegram_id, end_date)
        await update.callback_query.edit_message_text(
            f"✅ Підписку активовано до {end_date.strftime('%Y-%m-%d %H:%M:%S')} UTC\n"
            f"🔓 Тепер у вас необмежена кількість запрошень!",
            reply_markup=None
        )
        kb = [[InlineKeyboardButton("🔙 Повернутися до меню", callback_data="back")]]
        await update.effective_chat.send_message("Оберіть дію:", reply_markup=InlineKeyboardMarkup(kb))
        if 'invoice_id' in context.user_data:
            del context.user_data['invoice_id']
        return 12  # MAIN_MENU
    else:
        await update.callback_query.answer("❌ Оплату не виявлено", show_alert=True)
        return 15  # SUBSCRIBE

async def show_status(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Показує поточний статус підписки та пробних запрошень."""
    telegram_id = str(update.effective_chat.id)
    user = await db.get_user(telegram_id)

    if user:
        trial_left = user.trial_invites_left
        if user.subscription_end and user.subscription_end > datetime.utcnow():
            sub_end = user.subscription_end.strftime('%Y-%m-%d %H:%M:%S')
            status_text = f"✅ Підписка активна до {sub_end} UTC\n"
            status_text += "🔓 Ви можете виконувати необмежену кількість інвайтів."
        else:
            status_text = "❌ Підписка не активна\n"
            status_text += f"📨 Залишилось пробних запрошень: {trial_left}"
    else:
        status_text = "❌ Користувача не знайдено"

    await update.callback_query.edit_message_text(status_text)
    kb = [[InlineKeyboardButton("🔙 Повернутися до меню", callback_data="back")]]
    await update.effective_chat.send_message("Оберіть дію:", reply_markup=InlineKeyboardMarkup(kb))
    return 12  # MAIN_MENU
