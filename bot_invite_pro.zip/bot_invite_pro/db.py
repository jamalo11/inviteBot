import os
from typing import List, Optional
from datetime import datetime

from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker, declarative_base, relationship
from sqlalchemy import Column, Integer, String, ForeignKey, UniqueConstraint, select, delete, DateTime, func

DATABASE_URL = "sqlite+aiosqlite:///bot.sqlite3"

Base = declarative_base()

class User(Base):
    __tablename__ = "users"
    telegram_id = Column(String, primary_key=True, index=True)
    first_name = Column(String)
    last_name = Column(String)
    username = Column(String)
    trial_invites_left = Column(Integer, default=30)
    subscription_end = Column(DateTime, nullable=True)
    accounts = relationship("Account", back_populates="user", cascade="all, delete-orphan")

class Account(Base):
    __tablename__ = "accounts"
    id = Column(Integer, primary_key=True, index=True)
    telegram_id = Column(String, ForeignKey("users.telegram_id"))
    api_id = Column(Integer)
    api_hash = Column(String)
    phone = Column(String)
    __table_args__ = (UniqueConstraint("telegram_id", "phone", name="uix_telegram_phone"),)
    user = relationship("User", back_populates="accounts")

engine = create_async_engine(DATABASE_URL, echo=False)
async_session = sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)

async def init_db() -> None:
    """Створює таблиці в базі даних, якщо їх ще не існує."""
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

async def add_user(telegram_id: str, first_name: str, last_name: str, username: str) -> None:
    """Додає користувача до бази даних, якщо його ще не існує."""
    async with async_session() as session:
        async with session.begin():
            result = await session.execute(select(User).filter(User.telegram_id == telegram_id))
            user = result.scalar_one_or_none()
            if not user:
                user = User(
                    telegram_id=telegram_id,
                    first_name=first_name,
                    last_name=last_name,
                    username=username,
                    trial_invites_left=30,
                    subscription_end=None
                )
                session.add(user)

async def get_user(telegram_id: str) -> Optional[User]:
    """Повертає користувача з бази даних або None, якщо його немає."""
    async with async_session() as session:
        result = await session.execute(select(User).filter(User.telegram_id == telegram_id))
        return result.scalar_one_or_none()

async def add_account(telegram_id: str, api_id: int, api_hash: str, phone: str) -> None:
    """Додає акаунт для користувача до бази даних."""
    async with async_session() as session:
        async with session.begin():
            account = Account(
                telegram_id=telegram_id,
                api_id=api_id,
                api_hash=api_hash,
                phone=phone
            )
            session.add(account)

async def get_accounts(telegram_id: str) -> List[Account]:
    """Повертає список усіх акаунтів користувача."""
    async with async_session() as session:
        result = await session.execute(select(Account).filter(Account.telegram_id == telegram_id))
        return result.scalars().all()

async def delete_account(telegram_id: str, phone: str) -> None:
    """Видаляє акаунт користувача за telegram_id та номером телефону."""
    async with async_session() as session:
        async with session.begin():
            stmt = delete(Account).filter(
                Account.telegram_id == telegram_id,
                Account.phone == phone
            )
            await session.execute(stmt)

async def can_invite(telegram_id: str) -> bool:
    """Перевіряє, чи може користувач виконувати запрошення."""
    async with async_session() as session:
        user = await session.get(User, telegram_id)
        if user:
            if user.subscription_end and user.subscription_end > datetime.utcnow():
                return True  # Активна підписка = необмежені запрошення
            elif user.trial_invites_left > 0:
                return True  # Є пробні запрошення
        return False

async def decrement_trial_invite(telegram_id: str) -> None:
    """Зменшує кількість пробних запрошень на 1."""
    async with async_session() as session:
        async with session.begin():
            user = await session.get(User, telegram_id)
            if user and user.trial_invites_left > 0:
                user.trial_invites_left -= 1

async def set_subscription_end(telegram_id: str, end_date: datetime) -> None:
    """Встановлює дату закінчення підписки користувача."""
    async with async_session() as session:
        async with session.begin():
            user = await session.get(User, telegram_id)
            if user:
                user.subscription_end = end_date

async def get_total_users() -> int:
    """Повертає загальну кількість користувачів."""
    async with async_session() as session:
        result = await session.execute(select(func.count(User.telegram_id)))
        return result.scalar()

async def get_active_subscriptions() -> int:
    """Повертає кількість активних підписок."""
    async with async_session() as session:
        result = await session.execute(
            select(func.count(User.telegram_id)).where(User.subscription_end > datetime.utcnow())
        )
        return result.scalar()
