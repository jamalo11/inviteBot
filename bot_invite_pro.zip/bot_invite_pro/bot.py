import os
import re
import asyncio
import logging
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional, Tuple
from dotenv import load_dotenv

load_dotenv()

from telegram import Update, InlineKeyboardMarkup, InlineKeyboardButton, __version__ as telegram_version
from telegram.ext import (
    Application,
    CommandHandler,
    ConversationHandler,
    MessageHandler,
    CallbackQueryHandler,
    ContextTypes,
    filters,
)
from telethon import TelegramClient, errors
from telethon.tl.functions.channels import InviteToChannelRequest, JoinChannelRequest
from telethon.tl.functions.messages import ImportChatInviteRequest
from telethon.tl.types import User
import warnings
from telegram.warnings import PTBUserWarning
from sqlalchemy.orm import selectinload

import db
import subscriptions

warnings.filterwarnings("ignore", category=PTBUserWarning)

logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO,
    filename='bot_log.log'
)
logger = logging.getLogger(__name__)

# Conversation states
(ADD_API_ID, ADD_API_HASH, ADD_PHONE, ADD_CODE, ADD_PASSWORD,
 INVITE_ACCOUNT, INVITE_CHATLINK, INVITE_NUM, INVITE_DELAY, INVITE_FILE,
 DELETE_ACCOUNT, MAIN_MENU,
 BROADCAST_ACCOUNT, BROADCAST_CHATS, BROADCAST_MESSAGE,
 SUBSCRIBE, ADMIN_PANEL, ADMIN_BROADCAST_MESSAGE,
 ADMIN_MANAGE_USER, ADMIN_EDIT_USER) = range(20)

SESSIONS_DIR = "sessions"
TEMP_DIR = "temp_files"
os.makedirs(SESSIONS_DIR, exist_ok=True)
os.makedirs(TEMP_DIR, exist_ok=True)

# --- Account and Invitation Functions ---

async def authenticate_account(update: Update, context: ContextTypes.DEFAULT_TYPE,
                              api_id: int, api_hash: str, phone: str,
                              auth_processes: Dict[str, Dict[str, Any]]) -> Optional[bool]:
    telegram_id = str(update.effective_chat.id)
    normalized_phone = re.sub(r'\D', '', phone)
    session_path = os.path.join(SESSIONS_DIR, f'{normalized_phone}.session')
    client = TelegramClient(session_path, api_id, api_hash)
    await client.connect()
    logger.info(f"User {telegram_id} started authentication for phone {phone}")
    auth_processes[telegram_id] = {
        'client': client,
        'phone': phone,
        'api_id': api_id,
        'api_hash': api_hash
    }
    if await client.is_user_authorized():
        logger.info(f"Account {phone} already authorized for user {telegram_id}")
        await update.effective_message.reply_text("✅ Акаунт уже авторизовано")
        await client.disconnect()
        return True
    try:
        await client.send_code_request(phone)
        logger.info(f"Verification code sent to {phone} for user {telegram_id}")
        await update.effective_message.reply_text("📱 Код підтвердження надіслано. Введіть код (можна з пробілами):")
        return False
    except errors.FloodWaitError as e:
        logger.warning(f"FloodWaitError for user {telegram_id} on phone {phone}: wait {e.seconds} seconds")
        await update.effective_message.reply_text(f"⏳ Занадто багато запитів: зачекайте {e.seconds} секунд")
        await client.disconnect()
    except errors.PhoneNumberBannedError:
        logger.error(f"PhoneNumberBannedError for user {telegram_id}: phone {phone} is banned")
        await update.effective_message.reply_text("❌ Цей номер телефону заблоковано Telegram")
    except Exception as e:
        logger.error(f"Authentication error for user {telegram_id} on phone {phone}: {str(e)}")
        await update.effective_message.reply_text(f"❌ Помилка: {str(e)}")
    if telegram_id in auth_processes:
        del auth_processes[telegram_id]
    await client.disconnect()
    return None

async def handle_code_verification(update: Update, context: ContextTypes.DEFAULT_TYPE,
                                   code: str, auth_processes: Dict[str, Dict[str, Any]]) -> Optional[bool]:
    telegram_id = str(update.effective_chat.id)
    if telegram_id not in auth_processes:
        logger.warning(f"Session expired for user {telegram_id} during code verification")
        await update.effective_message.reply_text("❌ Сесія закінчилася")
        return None
    auth_data = auth_processes[telegram_id]
    client = auth_data['client']
    phone = auth_data['phone']
    logger.info(f"User {telegram_id} entered verification code for phone {phone}")
    code = ''.join(filter(str.isdigit, code))  # Remove all non-digit characters
    try:
        await client.sign_in(phone, code)
        if await client.is_user_authorized():
            logger.info(f"Authentication successful for user {telegram_id} on phone {phone}")
            await update.effective_message.reply_text("✅ Авторизація успішна!")
            await client.disconnect()
            return True
        return False
    except errors.SessionPasswordNeededError:
        logger.info(f"2FA required for user {telegram_id} on phone {phone}")
        await update.effective_message.reply_text("🔐 Потрібен 2FA. Введіть пароль:")
        return False
    except errors.PhoneCodeInvalidError:
        logger.warning(f"Invalid code entered by user {telegram_id} for phone {phone}")
        await update.effective_message.reply_text("❌ Невірний код. Спробуйте ще раз:")
    except Exception as e:
        logger.error(f"Verification error for user {telegram_id} on phone {phone}: {str(e)}")
        await update.effective_message.reply_text(f"❌ Помилка: {str(e)}")
    await client.disconnect()
    del auth_processes[telegram_id]
    return None

async def handle_2fa_verification(update: Update, context: ContextTypes.DEFAULT_TYPE,
                                  password: str, auth_processes: Dict[str, Dict[str, Any]]) -> bool:
    telegram_id = str(update.effective_chat.id)
    if telegram_id not in auth_processes:
        logger.warning(f"Session expired for user {telegram_id} during 2FA verification")
        await update.effective_message.reply_text("❌ Сесія закінчилася")
        return False
    client = auth_processes[telegram_id]['client']
    phone = auth_processes[telegram_id]['phone']
    logger.info(f"User {telegram_id} entered 2FA password for phone {phone}")
    try:
        await client.sign_in(password=password)
        logger.info(f"2FA verification successful for user {telegram_id} on phone {phone}")
        await update.effective_message.reply_text("✅ 2FA успішно пройдено!")
        await client.disconnect()
        return True
    except errors.PasswordHashInvalidError:
        logger.warning(f"Invalid 2FA password entered by user {telegram_id} for phone {phone}")
        await update.effective_message.reply_text("❌ Невірний пароль. Спробуйте ще раз:")
        return False
    except Exception as e:
        logger.error(f"2FA verification error for user {telegram_id} on phone {phone}: {str(e)}")
        await update.effective_message.reply_text(f"❌ Помилка: {str(e)}")
    await client.disconnect()
    del auth_processes[telegram_id]
    return False

async def invite_user(client, user: str, target_entity, cache: Dict[str, User]) -> Tuple[str, str, Optional[str]]:
    try:
        if user not in cache:
            try:
                cache[user] = await client.get_entity(user)
            except Exception as e:
                logger.error(f"Error fetching entity for {user}: {e}")
                return "skipped", user, None
        user_entity = cache[user]
        await client(InviteToChannelRequest(channel=target_entity, users=[user_entity]))
        return "success", user, None
    except errors.FloodWaitError:
        raise
    except errors.UserAlreadyParticipantError:
        logger.info(f"User {user} is already a participant")
        return "skipped", user, None
    except Exception as e:
        logger.error(f"Invite error for user {user}: {e}")
        return "failed", user, str(e)

async def run_invite_process(update: Update, context: ContextTypes.DEFAULT_TYPE,
                             account_data: Dict[str, Any], chat_link: str,
                             users_file: str, num_invites: int, delay: float) -> int:
    telegram_id = str(update.effective_chat.id)
    last_message = await update.effective_message.reply_text("🚀 Починаємо процес запрошення...")
    logger.info(f"Starting invite process for user {telegram_id}, account {account_data['phone']}, chat {chat_link}, {num_invites} invites")

    async def send_status(text: str):
        nonlocal last_message
        try:
            await last_message.delete()
        except Exception as e:
            logger.error(f"Error deleting previous message for user {telegram_id}: {e}")
        last_message = await update.effective_chat.send_message(text)
        context.user_data['last_message'] = last_message

    normalized_phone = re.sub(r'\D', '', account_data['phone'])
    session_path = os.path.join(SESSIONS_DIR, f'{normalized_phone}.session')
    client = TelegramClient(session_path, account_data['api_id'], account_data['api_hash'])
    try:
        await client.connect()
        if not await client.is_user_authorized():
            logger.warning(f"Account {account_data['phone']} not authorized for user {telegram_id}")
            await send_status("❌ Акаунт не авторизовано")
            kb = [[InlineKeyboardButton("🔙 Повернутися до меню", callback_data="back")]]
            await update.effective_chat.send_message("Оберіть дію:", reply_markup=InlineKeyboardMarkup(kb))
            return MAIN_MENU

        await send_status("🔄 Приєднуємося до чату...")
        try:
            if 't.me/+' in chat_link or 'joinchat' in chat_link:
                invite_hash = chat_link.split('/')[-1].replace('+', '')
                result = await client(ImportChatInviteRequest(invite_hash))
                target_entity = result.chats[0] if hasattr(result, 'chats') and result.chats else await client.get_entity(chat_link)
            else:
                target_entity = await client.get_entity(chat_link)
                await client(JoinChannelRequest(target_entity))
            logger.info(f"Successfully joined chat {chat_link} for user {telegram_id}")
        except Exception as e:
            logger.error(f"Join error for user {telegram_id} on chat {chat_link}: {e}")
            await send_status(f"❌ Помилка приєднання до чату: {str(e)}")
            kb = [[InlineKeyboardButton("🔙 Повернутися до меню", callback_data="back")]]
            await update.effective_chat.send_message("Оберіть дію:", reply_markup=InlineKeyboardMarkup(kb))
            return MAIN_MENU

        with open(users_file, 'r', encoding='utf-8') as f:
            users = [line.strip() for line in f if line.strip()][:num_invites]

        total = len(users)
        success = 0
        failed = 0
        skipped = 0
        cache: Dict[str, User] = {}
        max_retries = 3
        retry_delay = 1.5

        for i, user in enumerate(users):
            if not await db.can_invite(telegram_id):
                logger.warning(f"No invites left for user {telegram_id}")
                await send_status("❌ У вас закінчилися пробні запрошення та немає активної підписки. Придбайте підписку.")
                kb = [[InlineKeyboardButton("💳 Придбати підписку", callback_data="subscribe"),
                       InlineKeyboardButton("🔙 Повернутися до меню", callback_data="back")]]
                await update.effective_chat.send_message("Оберіть дію:", reply_markup=InlineKeyboardMarkup(kb))
                break

            for attempt in range(max_retries):
                try:
                    status, username, error_msg = await invite_user(client, user, target_entity, cache)
                    if status == "success":
                        success += 1
                        user_obj = await db.get_user(telegram_id)
                        if not (user_obj.subscription_end and user_obj.subscription_end > datetime.utcnow()):
                            await db.decrement_trial_invite(telegram_id)
                        logger.info(f"Invited {username} to {chat_link} by user {telegram_id}: success")
                        await send_status(
                            f"🎯 Прогрес: {i}/{total}. Залишилось у черзі: {total - i}\n"
                            f"✅ {username}"
                        )
                        break
                    elif status == "skipped":
                        skipped += 1
                        logger.info(f"Skipped inviting {username} to {chat_link} by user {telegram_id}")
                        await send_status(
                            f"🎯 Прогрес: {i}/{total}. Залишилось у черзі: {total - i}\n"
                            f"⏭️ {username} - Пропущено"
                        )
                        break
                    else:
                        if attempt < max_retries - 1:
                            logger.warning(f"Invite failed for {username} by user {telegram_id}: {error_msg}, retrying...")
                            await send_status(
                                f"🎯 Прогрес: {i}/{total}. Залишилось у черзі: {total - i}\n"
                                f"❌ Помилка при запрошенні {username}: {error_msg}. Чекаємо {retry_delay} сек..."
                            )
                            await asyncio.sleep(retry_delay)
                        else:
                            failed += 1
                            logger.error(f"Invite failed for {username} by user {telegram_id} after {max_retries} attempts: {error_msg}")
                            await send_status(
                                f"🎯 Прогрес: {i}/{total}. Залишилось у черзі: {total - i}\n"
                                f"❌ Помилка при запрошенні {username}: {error_msg} після {max_retries} спроб"
                            )
                            break
                except errors.FloodWaitError as e:
                    wait_time = e.seconds
                    if wait_time > 60:
                        logger.warning(f"FloodWaitError for user {telegram_id}: stopping process, wait {wait_time} seconds")
                        await send_status(
                            f"⏳ Занадто багато запитів: зачекайте {wait_time} секунд.\nПроцес зупинено."
                        )
                        context.job_queue.run_once(
                            notify_retry,
                            wait_time,
                            data={'chat_id': update.effective_chat.id, 'wait_time': wait_time, 'type': 'invite'}
                        )
                        return MAIN_MENU
                    else:
                        logger.warning(f"FloodWaitError for user {telegram_id}: waiting {wait_time} seconds")
                        await send_status(
                            f"🎯 Прогрес: {i}/{total}. Залишилось у черзі: {total - i}\n"
                            f"❌ Помилка при запрошенні {user}: Занадто багато запитів. Чекаємо {wait_time} сек..."
                        )
                        await asyncio.sleep(wait_time)
                        if attempt < max_retries - 1:
                            continue
                        else:
                            failed += 1
                            logger.error(f"Invite failed for {user} by user {telegram_id} after {max_retries} attempts due to flood wait")
                            await send_status(
                                f"🎯 Прогрес: {i}/{total}. Залишилось у черзі: {total - i}\n"
                                f"❌ Помилка при запрошенні {user}: Занадто багато запитів після {max_retries} спроб"
                            )
                            break

            if attempt == max_retries - 1 or status in ["success", "skipped"]:
                await send_status(
                    f"🎯 Прогрес: {i+1}/{total}. Залишилось у черзі: {total - i - 1}"
                )

            if delay > 0 and i < total - 1:
                await asyncio.sleep(delay)

        logger.info(f"Invite process completed for user {telegram_id}: Success {success}, Failed {failed}, Skipped {skipped}")
        await send_status(
            f"🎉 Завершено!\n"
            f"✅ Успішно: {success}\n"
            f"❌ Неуспішно: {failed}\n"
            f"⏭️ Пропущено: {skipped}"
        )
    except Exception as e:
        logger.error(f"Critical error in invite process for user {telegram_id}: {e}")
        await send_status(f"❌ Критична помилка: {str(e)}")
    finally:
        if 'last_message' in context.user_data:
            del context.user_data['last_message']
        await client.disconnect()
        kb = [[InlineKeyboardButton("🔙 Повернутися до меню", callback_data="back")]]
        await update.effective_chat.send_message("Оберіть дію:", reply_markup=InlineKeyboardMarkup(kb))

    return MAIN_MENU

# --- Broadcast Functions ---

async def start_broadcast(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    telegram_id = str(update.effective_chat.id)
    accounts = await db.get_accounts(telegram_id)
    logger.info(f"User {telegram_id} requested to start broadcast")

    if not accounts:
        logger.warning(f"No accounts available for broadcast for user {telegram_id}")
        if update.callback_query:
            await update.callback_query.edit_message_text("❌ У вас немає доступних акаунтів для розсилки")
        else:
            await update.effective_message.reply_text("❌ У вас немає доступних акаунтів для розсилки")
        kb = [[InlineKeyboardButton("🔙 Повернутися до меню", callback_data="back")]]
        await update.effective_chat.send_message("Оберіть дію:", reply_markup=InlineKeyboardMarkup(kb))
        return MAIN_MENU

    kb = [[InlineKeyboardButton(acc.phone, callback_data=f"broadcast_{acc.phone}")] for acc in accounts]
    kb.append([InlineKeyboardButton("🔙 Назад", callback_data="back")])

    if update.callback_query:
        await update.callback_query.edit_message_text(
            "Оберіть акаунт для розсилки:",
            reply_markup=InlineKeyboardMarkup(kb)
        )
    else:
        await update.message.reply_text(
            "Оберіть акаунт для розсилки:",
            reply_markup=InlineKeyboardMarkup(kb)
        )
    return BROADCAST_ACCOUNT

async def broadcast_account(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    phone = update.callback_query.data.split('_')[1]
    telegram_id = str(update.effective_chat.id)
    accounts = await db.get_accounts(telegram_id)
    account = next((acc for acc in accounts if acc.phone == phone), None)
    logger.info(f"User {telegram_id} selected account {phone} for broadcast")

    if not account:
        logger.warning(f"Account {phone} not found for user {telegram_id}")
        await update.callback_query.message.reply_text("❌ Акаунт не знайдено")
        return MAIN_MENU

    context.user_data['broadcast_account'] = {
        "api_id": account.api_id,
        "api_hash": account.api_hash,
        "phone": account.phone
    }

    await update.callback_query.answer()
    await update.callback_query.message.reply_text(
        "Надішліть список чатів для розсилки (кожен з нового рядка).\n"
        "Можна використовувати посилання або юзернейми чатів."
    )
    return BROADCAST_CHATS

async def broadcast_chats(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    chats = update.message.text.strip().split('\n')
    if not chats or all(not chat.strip() for chat in chats):
        logger.warning(f"Empty chat list provided by user {update.effective_chat.id}")
        await update.message.reply_text("❌ Список чатів порожній. Спробуйте ще раз:")
        return BROADCAST_CHATS
    context.user_data['broadcast_chats'] = chats
    logger.info(f"User {update.effective_chat.id} provided {len(chats)} chats for broadcast")

    await update.message.reply_text(
        "Надішліть повідомлення для розсилки.\n"
        "Підтримуються: текст, фото, стікери, документи, відео, анімації."
    )
    return BROADCAST_MESSAGE

async def broadcast_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    account_data = context.user_data['broadcast_account']
    chats = context.user_data['broadcast_chats']
    telegram_id = str(update.effective_chat.id)
    logger.info(f"User {telegram_id} initiated broadcast with account {account_data['phone']} to {len(chats)} chats")

    message = update.message
    context.user_data['broadcast_message'] = {
        'type': 'text' if message.text else 'media',
        'content': message.text_html if message.text else None,
        'file_path': None,
        'caption': message.caption_html if message.caption else None
    }

    file_path = None
    try:
        if message.photo:
            file = await message.photo[-1].get_file()
            file_path = f"{TEMP_DIR}/broadcast_{datetime.now().timestamp()}.jpg"
            await file.download_to_drive(file_path)
            context.user_data['broadcast_message'].update({
                'type': 'photo',
                'file_path': file_path
            })
        elif message.sticker:
            file = await message.sticker.get_file()
            file_path = f"{TEMP_DIR}/broadcast_{datetime.now().timestamp()}.webp"
            await file.download_to_drive(file_path)
            context.user_data['broadcast_message'].update({
                'type': 'sticker',
                'file_path': file_path
            })
        elif message.document:
            file = await message.document.get_file()
            file_path = f"{TEMP_DIR}/broadcast_{datetime.now().timestamp()}_{message.document.file_name}"
            await file.download_to_drive(file_path)
            context.user_data['broadcast_message'].update({
                'type': 'document',
                'file_path': file_path,
                'file_name': message.document.file_name
            })
        elif message.video:
            file = await message.video.get_file()
            file_path = f"{TEMP_DIR}/broadcast_{datetime.now().timestamp()}.mp4"
            await file.download_to_drive(file_path)
            context.user_data['broadcast_message'].update({
                'type': 'video',
                'file_path': file_path
            })
        elif message.animation:
            file = await message.animation.get_file()
            file_path = f"{TEMP_DIR}/broadcast_{datetime.now().timestamp()}.gif"
            await file.download_to_drive(file_path)
            context.user_data['broadcast_message'].update({
                'type': 'animation',
                'file_path': file_path
            })

        if not context.user_data['broadcast_message']['content'] and not file_path:
            logger.warning(f"Empty broadcast message from user {telegram_id}")
            await update.message.reply_text("❌ Повідомлення порожнє. Надішліть текст або медіа:")
            return BROADCAST_MESSAGE

        status_message = await update.message.reply_text("🚀 Починаємо розсилку...")
        cancel_button = InlineKeyboardButton("❌ Скасувати", callback_data="cancel_broadcast")
        reply_markup = InlineKeyboardMarkup([[cancel_button]])
        context.user_data['cancel_broadcast_event'] = asyncio.Event()

        status_message = await status_message.edit_text(
            "🔄 Підготовка до розсилки...",
            reply_markup=reply_markup
        )
        context.user_data['status_message'] = status_message

        normalized_phone = re.sub(r'\D', '', account_data['phone'])
        session_path = os.path.join(SESSIONS_DIR, f'{normalized_phone}.session')
        client = TelegramClient(session_path, account_data['api_id'], account_data['api_hash'])

        await client.connect()
        if not await client.is_user_authorized():
            logger.warning(f"Account {account_data['phone']} not authorized for broadcast by user {telegram_id}")
            await status_message.edit_text("❌ Акаунт не авторизовано", reply_markup=None)
            kb = [[InlineKeyboardButton("🔙 Повернутися до меню", callback_data="back")]]
            await update.effective_chat.send_message("Оберіть дію:", reply_markup=InlineKeyboardMarkup(kb))
            return MAIN_MENU

        total = len(chats)
        success = 0
        failed = 0

        for i, chat in enumerate(chats, 1):
            if context.user_data.get('cancel_broadcast_event') and context.user_data['cancel_broadcast_event'].is_set():
                logger.info(f"Broadcast cancelled by user {telegram_id}")
                await status_message.edit_text(
                    "❌ Розсилку скасовано користувачем.",
                    reply_markup=None
                )
                break

            try:
                if 't.me/+' in chat or 'joinchat' in chat:
                    invite_hash = chat.split('/')[-1].replace('+', '')
                    result = await client(ImportChatInviteRequest(invite_hash))
                    entity = result.chats[0] if hasattr(result, 'chats') and result.chats else await client.get_entity(chat)
                else:
                    entity = await client.get_entity(chat)
                    if hasattr(entity, 'broadcast') and entity.broadcast or hasattr(entity, 'megagroup') and entity.megagroup:
                        await client(JoinChannelRequest(entity))

                msg_data = context.user_data['broadcast_message']
                caption = msg_data.get('caption', '')

                if msg_data['type'] == 'text':
                    await client.send_message(entity, msg_data['content'], parse_mode='html')
                elif msg_data['type'] == 'photo':
                    await client.send_file(entity, msg_data['file_path'], caption=caption, parse_mode='html')
                elif msg_data['type'] == 'sticker':
                    await client.send_file(entity, msg_data['file_path'])
                elif msg_data['type'] == 'document':
                    await client.send_file(entity, msg_data['file_path'], caption=caption, parse_mode='html')
                elif msg_data['type'] == 'video':
                    await client.send_file(entity, msg_data['file_path'], caption=caption, parse_mode='html')
                elif msg_data['type'] == 'animation':
                    await client.send_file(entity, msg_data['file_path'], caption=caption, parse_mode='html')

                success += 1
                logger.info(f"Message sent to {chat} by user {telegram_id}: success")
                await asyncio.sleep(2)

            except errors.FloodWaitError as e:
                wait_time = e.seconds
                hours, remainder = divmod(wait_time, 3600)
                minutes, seconds = divmod(remainder, 60)
                time_format = f"{hours} год. " if hours > 0 else ""
                time_format += f"{minutes} хв. " if minutes > 0 else ""
                time_format += f"{seconds} сек."

                logger.warning(f"FloodWaitError in broadcast for user {telegram_id}: wait {wait_time} seconds")
                await status_message.edit_text(
                    f"⏳ Занадто багато запитів: зачекайте {time_format}.\nРозсилку зупинено.",
                    reply_markup=None
                )

                context.job_queue.run_once(
                    notify_retry,
                    wait_time,
                    data={'chat_id': update.effective_chat.id, 'wait_time': wait_time, 'type': 'broadcast'}
                )

                await client.disconnect()
                if file_path and os.path.exists(file_path):
                    os.remove(file_path)

                kb = [[InlineKeyboardButton("🔙 Повернутися до меню", callback_data="back")]]
                await update.effective_chat.send_message("Оберіть дію:", reply_markup=InlineKeyboardMarkup(kb))
                return MAIN_MENU

            except Exception as e:
                logger.error(f"Error sending to {chat} by user {telegram_id}: {e}")
                failed += 1

            try:
                await status_message.edit_text(
                    f"📊 Прогрес: {i}/{total}\n"
                    f"✅ Успішно: {success}\n"
                    f"❌ Неуспішно: {failed}",
                    reply_markup=reply_markup
                )
            except Exception as e:
                logger.error(f"Error updating status for user {telegram_id}: {e}")

        if not (context.user_data.get('cancel_broadcast_event') and context.user_data['cancel_broadcast_event'].is_set()):
            logger.info(f"Broadcast completed for user {telegram_id}: Total {total}, Success {success}, Failed {failed}")
            await status_message.edit_text(
                f"✅ Розсилку завершено!\n"
                f"Всього чатів: {total}\n"
                f"Успішно: {success}\n"
                f"Неуспішно: {failed}",
                reply_markup=None
            )

    except Exception as e:
        logger.error(f"Critical error in broadcast for user {telegram_id}: {e}")
        await status_message.edit_text(
            f"❌ Критична помилка: {str(e)}",
            reply_markup=None
        )
    finally:
        if 'status_message' in context.user_data:
            del context.user_data['status_message']
        if file_path and os.path.exists(file_path):
            try:
                os.remove(file_path)
            except Exception as e:
                logger.error(f"Error removing temp file for user {telegram_id}: {e}")
        try:
            await client.disconnect()
        except Exception as e:
            logger.error(f"Error disconnecting client for user {telegram_id}: {e}")

        kb = [[InlineKeyboardButton("🔙 Повернутися до меню", callback_data="back")]]
        await update.effective_chat.send_message("Оберіть дію:", reply_markup=InlineKeyboardMarkup(kb))

    return MAIN_MENU

async def cancel_broadcast(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    telegram_id = str(update.effective_chat.id)
    try:
        await query.answer("Скасування розсилки...")
    except Exception as e:
        logger.error(f"Failed to answer callback query for user {telegram_id}: {e}")

    if 'cancel_broadcast_event' in context.user_data:
        context.user_data['cancel_broadcast_event'].set()
    else:
        context.user_data['cancel_broadcast_event'] = asyncio.Event()
        context.user_data['cancel_broadcast_event'].set()

    try:
        if 'status_message' in context.user_data:
            await context.user_data['status_message'].edit_text(
                "❌ Розсилку скасовано користувачем.",
                reply_markup=None
            )
        else:
            await query.edit_message_text("❌ Запит на скасування отримано.", reply_markup=None)
    except Exception as e:
        logger.error(f"Error updating status on cancel for user {telegram_id}: {e}")

    kb = [[InlineKeyboardButton("🔙 Повернутися до меню", callback_data="back")]]
    await update.effective_chat.send_message("Оберіть дію:", reply_markup=InlineKeyboardMarkup(kb))
    return MAIN_MENU

# --- Notification Functions ---

async def notify_retry(context: ContextTypes.DEFAULT_TYPE):
    job = context.job
    chat_id = job.data['chat_id']
    wait_time = job.data.get('wait_time', 0)
    process_type = job.data.get('type', 'invite')

    hours, remainder = divmod(wait_time, 3600)
    minutes, seconds = divmod(remainder, 60)
    time_format = f"{hours} год. " if hours > 0 else ""
    time_format += f"{minutes} хв. " if minutes > 0 else ""
    time_format += f"{seconds} сек."

    process_name = "запрошення" if process_type == 'invite' else "розсилки"
    kb = [[InlineKeyboardButton("🔙 Повернутися до меню", callback_data="back")]]
    await context.bot.send_message(
        chat_id,
        f"⏰ Час очікування ({time_format}) закінчився. Можна знову запустити процес {process_name}.",
        reply_markup=InlineKeyboardMarkup(kb)
    )
    logger.info(f"Notified user {chat_id} that wait time of {wait_time} seconds has ended for {process_type}")

# --- Admin Panel ---

async def is_admin(telegram_id: str) -> bool:
    admin_id = os.getenv("ADMIN_ID")
    return telegram_id == admin_id

async def admin_panel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    telegram_id = str(update.effective_chat.id)
    if not await is_admin(telegram_id):
        logger.warning(f"Unauthorized access attempt to admin panel by user {telegram_id}")
        await update.message.reply_text("⛔ У вас немає доступу до адмін-панелі.")
        return ConversationHandler.END

    logger.info(f"Admin {telegram_id} accessed admin panel")
    keyboard = [
        [InlineKeyboardButton("👥 Список користувачів", callback_data="admin_users"),
         InlineKeyboardButton("📢 Відправити повідомлення всім", callback_data="admin_broadcast")],
        [InlineKeyboardButton("📊 Статистика", callback_data="admin_stats"),
         InlineKeyboardButton("👤 Керування користувачами", callback_data="admin_manage_users")],
        [InlineKeyboardButton("📈 Активні підписки", callback_data="admin_active_subs")],
        [InlineKeyboardButton("🔙 Повернутися до меню", callback_data="back")]
    ]
    await update.message.reply_text("<b>👑 Адмін-панель:</b>\nОберіть опцію:", reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='HTML')
    return ADMIN_PANEL

async def admin_users(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    telegram_id = str(update.effective_chat.id)
    async with db.async_session() as session:
        result = await session.execute(db.select(db.User).options(selectinload(db.User.accounts)))
        users = result.scalars().all()
        if not users:
            logger.info(f"No users found for admin {telegram_id}")
            await update.callback_query.edit_message_text("❌ Немає користувачів")
        else:
            response = "\n".join([
                f"ID: {user.telegram_id}, Підписка: {'✅' if user.subscription_end and user.subscription_end > datetime.utcnow() else '❌'}, "
                f"Запрошення: {user.trial_invites_left}, Акаунти: {len(user.accounts)}"
                for user in users
            ])
            logger.info(f"Admin {telegram_id} viewed list of {len(users)} users")
            await update.callback_query.edit_message_text(f"👥 Користувачі:\n{response}")
    kb = [[InlineKeyboardButton("🔙 Повернутися до адмін-панелі", callback_data="admin_back")]]
    await update.effective_chat.send_message("Оберіть дію:", reply_markup=InlineKeyboardMarkup(kb))
    return ADMIN_PANEL

async def admin_active_subscriptions(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    telegram_id = str(update.effective_chat.id)
    async with db.async_session() as session:
        result = await session.execute(
            db.select(db.User).where(db.User.subscription_end > datetime.utcnow()).options(selectinload(db.User.accounts))
        )
        users = result.scalars().all()
        if not users:
            logger.info(f"No active subscriptions found for admin {telegram_id}")
            await update.callback_query.edit_message_text("❌ Немає активних підписок")
        else:
            response = "\n".join([
                f"ID: {user.telegram_id}, Підписка до: {user.subscription_end.strftime('%Y-%m-%d %H:%M:%S')}, "
                f"Запрошення: {user.trial_invites_left}, Акаунти: {len(user.accounts)}"
                for user in users
            ])
            logger.info(f"Admin {telegram_id} viewed {len(users)} active subscriptions")
            await update.callback_query.edit_message_text(f"📈 Активні підписки:\n{response}")
    kb = [[InlineKeyboardButton("🔙 Повернутися до адмін-панелі", callback_data="admin_back")]]
    await update.effective_chat.send_message("Оберіть дію:", reply_markup=InlineKeyboardMarkup(kb))
    return ADMIN_PANEL

async def admin_broadcast(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    telegram_id = str(update.effective_chat.id)
    logger.info(f"Admin {telegram_id} initiated broadcast to all users")
    await update.callback_query.edit_message_text(
        "Надішліть повідомлення для розсилки всім користувачам (підтримуються текст, фото, стікери тощо):"
    )
    return ADMIN_BROADCAST_MESSAGE

async def send_broadcast(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    telegram_id = str(update.effective_chat.id)
    message = update.message
    async with db.async_session() as session:
        result = await session.execute(db.select(db.User))
        users = result.scalars().all()
        logger.info(f"Admin {telegram_id} sending broadcast to {len(users)} users")
        for user in users:
            try:
                await context.bot.copy_message(
                    chat_id=user.telegram_id,
                    from_chat_id=update.message.chat_id,
                    message_id=message.message_id
                )
            except Exception as e:
                logger.error(f"Failed to send broadcast to user {user.telegram_id} by admin {telegram_id}: {e}")
    await update.message.reply_text("✅ Розсилку завершено")
    kb = [[InlineKeyboardButton("🔙 Повернутися до адмін-панелі", callback_data="admin_back")]]
    await update.message.reply_text("Оберіть дію:", reply_markup=InlineKeyboardMarkup(kb))
    return ADMIN_PANEL

async def admin_stats(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    telegram_id = str(update.effective_chat.id)
    total_users = await db.get_total_users()
    active_subs = await db.get_active_subscriptions()
    logger.info(f"Admin {telegram_id} viewed stats: {total_users} total users, {active_subs} active subscriptions")
    await update.callback_query.edit_message_text(
        f"📊 Статистика:\n"
        f"Всього користувачів: {total_users}\n"
        f"Активних підписок: {active_subs}"
    )
    kb = [[InlineKeyboardButton("🔙 Повернутися до адмін-панелі", callback_data="admin_back")]]
    await update.effective_chat.send_message("Оберіть дію:", reply_markup=InlineKeyboardMarkup(kb))
    return ADMIN_PANEL

async def admin_manage_users(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    telegram_id = str(update.effective_chat.id)
    async with db.async_session() as session:
        result = await session.execute(db.select(db.User))
        users = result.scalars().all()
        if not users:
            logger.info(f"No users available for management by admin {telegram_id}")
            await update.callback_query.edit_message_text("❌ Немає користувачів")
            kb = [[InlineKeyboardButton("🔙 Повернутися до адмін-панелі", callback_data="admin_back")]]
            await update.effective_chat.send_message("Оберіть дію:", reply_markup=InlineKeyboardMarkup(kb))
            return ADMIN_PANEL
        kb = [[InlineKeyboardButton(f"{user.telegram_id}", callback_data=f"manage_user_{user.telegram_id}")] for user in users]
        kb.append([InlineKeyboardButton("🔙 Назад", callback_data="admin_back")])
        await update.callback_query.edit_message_text("Оберіть користувача для керування:", reply_markup=InlineKeyboardMarkup(kb))
    return ADMIN_MANAGE_USER

async def manage_user(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    telegram_id = str(update.effective_chat.id)
    user_id = update.callback_query.data.split('_')[2]
    context.user_data['manage_user_id'] = user_id
    logger.info(f"Admin {telegram_id} managing user {user_id}")
    kb = [
        [InlineKeyboardButton("📅 Продовжити підписку", callback_data="extend_subscription"),
         InlineKeyboardButton("🔄 Скинути пробні запрошення", callback_data="reset_trial_invites")],
        [InlineKeyboardButton("🔙 Назад", callback_data="admin_manage_users")]
    ]
    await update.callback_query.edit_message_text(f"Керування користувачем {user_id}:", reply_markup=InlineKeyboardMarkup(kb))
    return ADMIN_EDIT_USER

async def extend_subscription(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    telegram_id = str(update.effective_chat.id)
    user_id = context.user_data.get('manage_user_id')
    if not user_id:
        logger.warning(f"No user selected for subscription extension by admin {telegram_id}")
        await update.callback_query.edit_message_text("❌ Користувача не вибрано")
        return ADMIN_PANEL
    logger.info(f"Admin {telegram_id} requested to extend subscription for user {user_id}")
    await update.callback_query.edit_message_text("Введіть кількість днів для продовження підписки:")
    context.user_data['extend_days'] = True
    return ADMIN_EDIT_USER

async def reset_trial_invites(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    telegram_id = str(update.effective_chat.id)
    user_id = context.user_data.get('manage_user_id')
    if not user_id:
        logger.warning(f"No user selected for trial invites reset by admin {telegram_id}")
        await update.callback_query.edit_message_text("❌ Користувача не вибрано")
        return ADMIN_PANEL
    async with db.async_session() as session:
        user = await session.get(db.User, user_id)
        if user:
            user.trial_invites_left = 30  # Default value
            await session.commit()
            logger.info(f"Admin {telegram_id} reset trial invites for user {user_id} to 30")
            await update.callback_query.edit_message_text(f"✅ Пробні запрошення для користувача {user_id} скинуто")
        else:
            logger.warning(f"User {user_id} not found for trial invites reset by admin {telegram_id}")
            await update.callback_query.edit_message_text(f"❌ Користувача {user_id} не знайдено")
    kb = [[InlineKeyboardButton("🔙 Повернутися до керування користувачами", callback_data="admin_manage_users")]]
    await update.effective_chat.send_message("Оберіть дію:", reply_markup=InlineKeyboardMarkup(kb))
    return ADMIN_PANEL

async def handle_extend_days(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    telegram_id = str(update.effective_chat.id)
    try:
        days = int(update.message.text)
        user_id = context.user_data.get('manage_user_id')
        if not user_id:
            logger.warning(f"No user selected for subscription extension by admin {telegram_id}")
            await update.message.reply_text("❌ Користувача не вибрано")
            return ADMIN_PANEL
        async with db.async_session() as session:
            user = await session.get(db.User, user_id)
            if user:
                if user.subscription_end and user.subscription_end > datetime.utcnow():
                    new_end = user.subscription_end + timedelta(days=days)
                else:
                    new_end = datetime.utcnow() + timedelta(days=days)
                user.subscription_end = new_end
                await session.commit()
                logger.info(f"Admin {telegram_id} extended subscription for user {user_id} by {days} days to {new_end}")
                await update.message.reply_text(f"✅ Підписку для користувача {user_id} продовжено на {days} днів до {new_end.strftime('%Y-%m-%d %H:%M:%S')} UTC")
            else:
                logger.warning(f"User {user_id} not found for subscription extension by admin {telegram_id}")
                await update.message.reply_text(f"❌ Користувача {user_id} не знайдено")
    except ValueError:
        logger.warning(f"Invalid days input by admin {telegram_id} for user {context.user_data.get('manage_user_id')}")
        await update.message.reply_text("❌ Невірна кількість днів. Введіть число:")
        return ADMIN_EDIT_USER
    kb = [[InlineKeyboardButton("🔙 Повернутися до керування користувачами", callback_data="admin_manage_users")]]
    await update.message.reply_text("Оберіть дію:", reply_markup=InlineKeyboardMarkup(kb))
    return ADMIN_PANEL

async def admin_back(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    await update.callback_query.answer()
    return await admin_panel(update, context)

# --- /help Command ---

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    telegram_id = str(update.effective_chat.id)
    logger.info(f"User {telegram_id} requested help")
    help_text = (
        "ℹ️ <b>Допомога</b>\n\n"
        "Для отримання <b>детальної інформації про можливості бота</b>, інструкцій з використання та оновлень — будь ласка, перейдіть до нашого каналу:"
    )

    keyboard = [
        [InlineKeyboardButton("📢 Перейти до каналу", url="https://t.me/hushinvite")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)

    await update.message.reply_text(help_text, reply_markup=reply_markup, parse_mode='HTML')

# --- Main Bot Functions ---

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    telegram_id = str(update.effective_chat.id)
    first_name = update.effective_chat.first_name or ""
    last_name = update.effective_chat.last_name or ""
    username = update.effective_chat.username or ""
    await db.add_user(telegram_id, first_name, last_name, username)
    logger.info(f"User {telegram_id} started bot")

    keyboard = [
        [InlineKeyboardButton("➕ Додати акаунт", callback_data="add_account"),
         InlineKeyboardButton("📋 Список акаунтів", callback_data="list_accounts")],
        [InlineKeyboardButton("🚀 Розпочати запрошення", callback_data="start_invites"),
         InlineKeyboardButton("📢 Розпочати розсилку", callback_data="start_broadcast")],
        [InlineKeyboardButton("🗑️ Видалити акаунт", callback_data="delete_account"),
         InlineKeyboardButton("💳 Купити підписку", callback_data="subscribe")],
        [InlineKeyboardButton("📊 Мій статус", callback_data="status")]
    ]
    await update.effective_message.reply_text("<b>👋 Ласкаво просимо!</b>\nОберіть опцію:", reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='HTML')
    return MAIN_MENU

async def handle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    telegram_id = str(update.effective_chat.id)
    await query.answer()
    data = query.data
    logger.info(f"User {telegram_id} triggered callback: {data}")
    if data == 'add_account':
        await query.edit_message_text("Введіть API_ID (отримайте на my.telegram.org):")
        return ADD_API_ID
    elif data == 'list_accounts':
        accounts = await db.get_accounts(telegram_id)
        response = "\n".join([f"{i+1}. {acc.phone}" for i, acc in enumerate(accounts)]) if accounts else "У вас немає доданих акаунтів"
        await query.edit_message_text(f"📱 Ваші акаунти:\n{response}")
        kb = [[InlineKeyboardButton("🔙 Повернутися до меню", callback_data="back")]]
        await query.message.reply_text("Оберіть дію:", reply_markup=InlineKeyboardMarkup(kb))
        return MAIN_MENU
    elif data == 'start_invites':
        return await start_invites(update, context)
    elif data == 'start_broadcast':
        return await start_broadcast(update, context)
    elif data == 'delete_account':
        return await delete_account(update, context)
    elif data == 'subscribe':
        return await subscriptions.start_subscription(update, context)
    elif data == 'status':
        return await subscriptions.show_status(update, context)
    elif data == 'back':
        return await start(update, context)
    return MAIN_MENU

async def add_api_id(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    telegram_id = str(update.effective_chat.id)
    try:
        context.user_data['api_id'] = int(update.message.text)
        logger.info(f"User {telegram_id} entered API_ID")
        await update.message.reply_text("Введіть API_HASH (отримайте на my.telegram.org):")
        return ADD_API_HASH
    except ValueError:
        logger.warning(f"Invalid API_ID input by user {telegram_id}")
        await update.message.reply_text("❌ Невірний API_ID. Введіть числове значення:")
        return ADD_API_ID

async def add_api_hash(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    telegram_id = str(update.effective_chat.id)
    context.user_data['api_hash'] = update.message.text
    logger.info(f"User {telegram_id} entered API_HASH")
    await update.message.reply_text("Введіть номер телефону (в міжнародному форматі з +, наприклад, +380123456789):")
    return ADD_PHONE

async def add_phone(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    telegram_id = str(update.effective_chat.id)
    phone = update.message.text
    if not re.match(r'^\+\d{10,15}$', phone):
        logger.warning(f"Invalid phone format by user {telegram_id}: {phone}")
        await update.message.reply_text("❌ Невірний формат номера. Введіть у форматі +380123456789:")
        return ADD_PHONE
    context.user_data['phone'] = phone
    logger.info(f"User {telegram_id} entered phone {phone}")
    auth_processes = context.bot_data.setdefault('auth_processes', {})
    result = await authenticate_account(update, context, context.user_data['api_id'], context.user_data['api_hash'], phone, auth_processes)
    if result is True:
        await db.add_account(telegram_id, context.user_data['api_id'], context.user_data['api_hash'], phone)
        logger.info(f"Account {phone} saved for user {telegram_id}")
        await update.effective_message.reply_text("✅ Акаунт успішно додано!")
        return await start(update, context)
    elif result is False:
        return ADD_CODE
    return MAIN_MENU

async def add_code(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    telegram_id = str(update.effective_chat.id)
    code = update.message.text
    auth_processes = context.bot_data.get('auth_processes', {})
    result = await handle_code_verification(update, context, code, auth_processes)
    if result is True:
        await db.add_account(telegram_id, context.user_data['api_id'], context.user_data['api_hash'], context.user_data['phone'])
        logger.info(f"Account {context.user_data['phone']} saved for user {telegram_id} after code verification")
        return await start(update, context)
    elif result is False:
        return ADD_PASSWORD
    return ADD_CODE

async def add_password(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    telegram_id = str(update.effective_chat.id)
    password = update.message.text
    auth_processes = context.bot_data.get('auth_processes', {})
    if await handle_2fa_verification(update, context, password, auth_processes):
        await db.add_account(telegram_id, context.user_data['api_id'], context.user_data['api_hash'], context.user_data['phone'])
        logger.info(f"Account {context.user_data['phone']} saved for user {telegram_id} after 2FA")
        return await start(update, context)
    return ADD_PASSWORD

async def start_invites(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    telegram_id = str(update.effective_chat.id)
    accounts = await db.get_accounts(telegram_id)
    logger.info(f"User {telegram_id} requested to start invites")
    if not accounts:
        logger.warning(f"No accounts available for invites for user {telegram_id}")
        await update.effective_message.reply_text("❌ У вас немає доданих акаунтів. Додайте акаунт спочатку.")
        kb = [[InlineKeyboardButton("🔙 Повернутися до меню", callback_data="back")]]
        await update.effective_chat.send_message("Оберіть дію:", reply_markup=InlineKeyboardMarkup(kb))
        return MAIN_MENU
    kb = [[InlineKeyboardButton(acc.phone, callback_data=f"invite_{acc.phone}")] for acc in accounts]
    kb.append([InlineKeyboardButton("🔙 Назад", callback_data="back")])
    if update.callback_query:
        await update.callback_query.edit_message_text("Оберіть акаунт для запрошень:", reply_markup=InlineKeyboardMarkup(kb))
    else:
        await update.message.reply_text("Оберіть акаунт для запрошень:", reply_markup=InlineKeyboardMarkup(kb))
    return INVITE_ACCOUNT

async def invite_account(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    telegram_id = str(update.effective_chat.id)
    phone = update.callback_query.data.split('_')[1]
    accounts = await db.get_accounts(telegram_id)
    account = next((acc for acc in accounts if acc.phone == phone), None)
    logger.info(f"User {telegram_id} selected account {phone} for invites")
    if not account:
        logger.warning(f"Account {phone} not found for user {telegram_id}")
        await update.callback_query.message.reply_text("❌ Акаунт не знайдено")
        return MAIN_MENU
    context.user_data['invite_account'] = {"api_id": account.api_id, "api_hash": account.api_hash, "phone": account.phone}
    await update.callback_query.message.reply_text("Введіть посилання на чат/запрошення:")
    return INVITE_CHATLINK

async def invite_chat_link(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    telegram_id = str(update.effective_chat.id)
    context.user_data['chat_link'] = update.message.text
    logger.info(f"User {telegram_id} entered chat link: {update.message.text}")
    await update.message.reply_text("Введіть кількість запрошень:")
    return INVITE_NUM

async def invite_number(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    telegram_id = str(update.effective_chat.id)
    try:
        num = int(update.message.text)
        if num <= 0:
            raise ValueError
        context.user_data['num_invites'] = num
        logger.info(f"User {telegram_id} set number of invites: {num}")
        await update.message.reply_text("Введіть затримку між запрошеннями (в секундах):")
        return INVITE_DELAY
    except ValueError:
        logger.warning(f"Invalid number of invites by user {telegram_id}: {update.message.text}")
        await update.message.reply_text("❌ Невірне число. Введіть позитивне число:")
        return INVITE_NUM

async def invite_delay(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    telegram_id = str(update.effective_chat.id)
    try:
        delay = float(update.message.text)
        if delay < 0:
            raise ValueError
        context.user_data['delay'] = delay
        logger.info(f"User {telegram_id} set delay: {delay} seconds")
        await update.message.reply_text("Надішліть файл users.txt (список юзернеймів для запрошення):")
        return INVITE_FILE
    except ValueError:
        logger.warning(f"Invalid delay by user {telegram_id}: {update.message.text}")
        await update.message.reply_text("❌ Невірна затримка. Введіть невід'ємне число:")
        return INVITE_DELAY

async def invite_file(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    telegram_id = str(update.effective_chat.id)
    file = await update.message.document.get_file()
    filename = f"temp_{datetime.now().timestamp()}.txt"
    temp_path = os.path.join(TEMP_DIR, filename)
    await file.download_to_drive(temp_path)
    logger.info(f"User {telegram_id} uploaded users.txt for invites")
    try:
        new_state = await run_invite_process(update, context, context.user_data['invite_account'],
                                             context.user_data['chat_link'], temp_path,
                                             context.user_data['num_invites'], context.user_data['delay'])
    finally:
        if os.path.exists(temp_path):
            os.remove(temp_path)
    return new_state

async def delete_account(update: Update, context: ContextTypes.DEFAULT_TYPE):
    telegram_id = str(update.effective_chat.id)
    accounts = await db.get_accounts(telegram_id)
    logger.info(f"User {telegram_id} requested to delete an account")
    if not accounts:
        logger.warning(f"No accounts available for deletion by user {telegram_id}")
        await update.effective_message.reply_text("❌ У вас немає акаунтів для видалення")
        kb = [[InlineKeyboardButton("🔙 Повернутися до меню", callback_data="back")]]
        await update.effective_chat.send_message("Оберіть дію:", reply_markup=InlineKeyboardMarkup(kb))
        return MAIN_MENU
    kb = [[InlineKeyboardButton(acc.phone, callback_data=f"delacc_{acc.phone}")] for acc in accounts]
    kb.append([InlineKeyboardButton("🔙 Назад", callback_data="back")])
    if update.callback_query:
        await update.callback_query.edit_message_text("Оберіть акаунт для видалення:", reply_markup=InlineKeyboardMarkup(kb))
    else:
        await update.message.reply_text("Оберіть акаунт для видалення:", reply_markup=InlineKeyboardMarkup(kb))
    return DELETE_ACCOUNT

async def confirm_delete(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    telegram_id = str(update.effective_chat.id)
    phone = update.callback_query.data.split('_')[1]
    await db.delete_account(telegram_id, phone)
    logger.info(f"User {telegram_id} deleted account {phone}")
    await update.callback_query.edit_message_text(f"✅ Акаунт {phone} видалено")
    kb = [[InlineKeyboardButton("🔙 Повернутися до меню", callback_data="back")]]
    await update.callback_query.message.reply_text("Оберіть дію:", reply_markup=InlineKeyboardMarkup(kb))
    return MAIN_MENU

async def error_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    telegram_id = update.effective_chat.id if update else "unknown"
    logger.error(f"Error processing update for user {telegram_id}: {context.error}")
    try:
        if update:
            await update.effective_message.reply_text(f"❌ Помилка: {context.error}\nСпробуйте ще раз з /start")
    except Exception as e:
        logger.error(f"Failed to send error message to user {telegram_id}: {e}")

# --- Bot Startup ---

async def init_database():
    await db.init_db()
    logger.info("Database initialized")

async def start_bot():
    token = os.getenv("BOT_TOKEN")
    if not token:
        logger.error("BOT_TOKEN not found!")
        return

    logger.info(f"Using python-telegram-bot version: {telegram_version}")
    if telegram_version < "20.0":
        logger.error("Requires python-telegram-bot version 20.x or higher")
        return

    application = Application.builder().token(token).build()

    conv_handler = ConversationHandler(
        entry_points=[CommandHandler('start', start), CommandHandler('admin', admin_panel)],
        states={
            MAIN_MENU: [
                CallbackQueryHandler(handle_callback, pattern=r'^(add_account|list_accounts|start_invites|start_broadcast|delete_account|subscribe|status|back)$'),
            ],
            ADD_API_ID: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_api_id)],
            ADD_API_HASH: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_api_hash)],
            ADD_PHONE: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_phone)],
            ADD_CODE: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_code)],
            ADD_PASSWORD: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_password)],
            INVITE_ACCOUNT: [
                CallbackQueryHandler(invite_account, pattern=r'^invite_'),
                CallbackQueryHandler(handle_callback, pattern=r'^back$')
            ],
            INVITE_CHATLINK: [MessageHandler(filters.TEXT & ~filters.COMMAND, invite_chat_link)],
            INVITE_NUM: [MessageHandler(filters.TEXT & ~filters.COMMAND, invite_number)],
            INVITE_DELAY: [MessageHandler(filters.TEXT & ~filters.COMMAND, invite_delay)],
            INVITE_FILE: [
                MessageHandler(filters.Document.FileExtension("txt"), invite_file)
            ],
            DELETE_ACCOUNT: [
                CallbackQueryHandler(confirm_delete, pattern=r'^delacc_'),
                CallbackQueryHandler(handle_callback, pattern=r'^back$')
            ],
            BROADCAST_ACCOUNT: [
                CallbackQueryHandler(broadcast_account, pattern=r'^broadcast_'),
                CallbackQueryHandler(handle_callback, pattern=r'^back$')
            ],
            BROADCAST_CHATS: [MessageHandler(filters.TEXT & ~filters.COMMAND, broadcast_chats)],
            BROADCAST_MESSAGE: [
                MessageHandler(
                    filters.TEXT | filters.PHOTO | filters.Sticker.ALL | filters.Document.ALL | filters.VIDEO | filters.ANIMATION,
                    broadcast_message
                ),
                CallbackQueryHandler(cancel_broadcast, pattern='^cancel_broadcast$')
            ],
            SUBSCRIBE: [
                CallbackQueryHandler(subscriptions.check_payment, pattern='^check_payment$'),
                CallbackQueryHandler(handle_callback, pattern='^back$')
            ],
            ADMIN_PANEL: [
                CallbackQueryHandler(admin_users, pattern='^admin_users$'),
                CallbackQueryHandler(admin_broadcast, pattern='^admin_broadcast$'),
                CallbackQueryHandler(admin_stats, pattern='^admin_stats$'),
                CallbackQueryHandler(admin_manage_users, pattern='^admin_manage_users$'),
                CallbackQueryHandler(admin_active_subscriptions, pattern='^admin_active_subs$'),
                CallbackQueryHandler(handle_callback, pattern='^back$'),
                CallbackQueryHandler(admin_back, pattern='^admin_back$')
            ],
            ADMIN_BROADCAST_MESSAGE: [
                MessageHandler(
                    filters.TEXT | filters.PHOTO | filters.Sticker.ALL | filters.Document.ALL | filters.VIDEO | filters.ANIMATION,
                    send_broadcast
                )
            ],
            ADMIN_MANAGE_USER: [
                CallbackQueryHandler(manage_user, pattern=r'^manage_user_'),
                CallbackQueryHandler(admin_back, pattern='^admin_back$')
            ],
            ADMIN_EDIT_USER: [
                CallbackQueryHandler(extend_subscription, pattern='^extend_subscription$'),
                CallbackQueryHandler(reset_trial_invites, pattern='^reset_trial_invites$'),
                CallbackQueryHandler(admin_manage_users, pattern='^admin_manage_users$'),
                MessageHandler(filters.TEXT & ~filters.COMMAND, handle_extend_days),
            ],
        },
        fallbacks=[
            CommandHandler('start', start),
            CommandHandler('cancel', lambda u, c: MAIN_MENU),
            CallbackQueryHandler(lambda u, c: MAIN_MENU, pattern='^cancel$')
        ],
        allow_reentry=True,
        per_message=False
    )
    application.add_handler(conv_handler)
    application.add_handler(CommandHandler('help', help_command))
    application.add_error_handler(error_handler)

    logger.info("Bot started")
    await application.initialize()
    await application.start()
    await application.updater.start_polling()
    try:
        while True:
            await asyncio.sleep(1)
    except (KeyboardInterrupt, SystemExit):
        logger.info("Bot shutting down")
        await application.stop()
        await application.shutdown()

async def main():
    await init_database()
    await start_bot()

if __name__ == '__main__':
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print('Бот вимкнено')
